﻿from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.bash_operator import BashOperator

default_args = {
   'owner': 'rubens_zimbres',
   'depends_on_past': False,
   'start_date': datetime(2019, 8, 9),
   'retries': 1,
   }

with DAG(
   'first-dag',
   schedule_interval=timedelta(minutes=1),
   catchup=False,
   default_args=default_args
   ) as dag:

    t1 = BashOperator(
   task_id='first_etl',
   bash_command="""
   cd AIRFLOW_HOME/dags/etl_scripts/
   python3 first_etl.py
   """)
    t2 = BashOperator(
   task_id='second_etl',
   bash_command="""
   cd AIRFLOW_HOME/dags/etl_scripts/
   python3 second_etl.py
   """)

t1 >> t2
